# MiniMax H3 契约与 New API 插件

依据 [接口文档](http://110.42.35.62:3000/zh/docs) 及其公开 `minimax-h3` 详情生成，读取日期为 2026-10-23。仅包含精确模型 ID `MiniMax H3`。

## 文件

- `contract.json`：可导入本项目的视频契约，导入格式版本 4。
- `minimax-h3-v1.0.1.js`：上传到 New API 的独立 JavaScript 插件，标识 `minimax-h3`，版本 `1.0.1`。
- `source-document.json`：生成时读取的公开接口文档，不包含 Key。
- `contract-dry-run.json`、`plugin-dry-run.json`：本地干跑报告。

## New API 配置

1. 在插件管理中上传 `minimax-h3-v1.0.1.js` 并激活。
2. 创建或调整“任务插件”渠道，绑定 `minimax-h3`。
3. Base URL 使用 `http://110.42.35.62:3000`，在渠道中填写该供应商的实际 Key。插件不包含 Key，也不预设默认地址；实际请求使用渠道配置。
4. 模型填写 `MiniMax H3`，保留大小写与空格。
5. 按自己的计费规则配置价格；插件只报告请求秒数，不包含售价。

插件对外仅声明 `openai_video`。创建、查询、下载分别使用 `/v1/videos`、`/v1/videos/{id}`、`/v1/videos/{id}/content`。下载携带渠道 Bearer Key，依照文档按任务 ID 获取二进制内容，不猜测结果 URL 字段。生产 New API 需支持当前 multipart 文件引用 API。

## 参数与素材

- `prompt` 必填；`seconds` 为 4–15 的整数；`size` 保留文档的全部 26 个原始选项。
- 默认 5 秒、`1376x768` 取自文档示例，作为客户端默认值，不代表供应商声明了服务端默认值。
- `aspect_ratio` 是独立选填参数，支持文档的 8 个比例；`prompt_enhance` 为选填布尔值，显式 `false` 会保留。
- 文档中的选填 `mode` 作为字符串原样传递，不将其当作契约的生成模式，也不推测未声明的枚举。
- 文生视频不携带素材；参考模式使用 `images`、`reference_videos`、`reference_audios`，分别最多 9、3、3 份。总上限 15 是三个字段上限之和，文档未另行声明跨类型组合限制。
- URL 请求使用 JSON 数组；本地上传使用 multipart，各类文件分别重复相应字段名，不能手写 boundary。按文档现有证据，不启用文件与 URL 混传。
- 文档另有 `input_reference`、`reference_video`、`reference_audio` 单值入口；本契约统一使用上述三个数组入口，不支持将这些别名叠加提交。图像参考属于参考模式，文档未将其定义为首尾帧。
- 轮询配置默认间隔 5 秒、超时 900 秒。New API 实际任务调度与超时仍由宿主配置决定。

## 验证范围

契约结构、两个生成模式及插件创建、查询、状态、用量、下载干跑通过。额外验证 26 个尺寸 × 12 个时长的 312 组 JSON 请求、附加参数、非法输入拒绝，以及 9 图片 + 3 视频 + 3 音频的 multipart 路由与超限拒绝。

干跑没有发送供应商请求，没有生成付费视频；不代表所有素材、参数组合已经在生产上游实测。

## 1.0.1 规范同步

按 QuantumNous/new-api `33c61a24234aa20cb10e8a644304322c476361de`（2026-10-23）核对。新版省略默认 `meta.baseUrl`，显式声明 `meta.auth: "api_key"`，支持渠道模型别名与供应商端点 ID 的能力选择，并按规范使用“视频生成单价”作为秒数计费字段的展示标签。旧版文件保留，上传升级时选择 `1.0.1`。

`newapi-host-fixture.json` 包含 19 项可用官方 `new-api plugin test <插件文件> --fixture <测试文件>` 重放的样本；`newapi-host-validation.json` 记录官方源码版本、校验命令及通过结果。这些测试只运行插件沙盒，不请求真实上游。
